# Install Istio on an existing Kubernetes cluster

Please follow the installation instructions from [istio.io](https://istio.io/docs/setup/kubernetes/quick-start.html).

If you prefer to install Istio by checking out the [istio/istio](https://github.com/istio/istio) repository, you can run `updateVersion.sh`
in the parent directory to generate the required installation files.
