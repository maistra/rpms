---
name: Feature request
about: Suggest an idea to improve Istio

---

**Describe the feature request**
{{ Succinctly describe your request }}

**Describe alternatives you've considered**
{{ Describe alternative solutions or workarounds you've considered. }}

**Additional context**
{{ Add any other context about the feature request here }}
